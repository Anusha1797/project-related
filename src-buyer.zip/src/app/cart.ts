export class cart {
    cartId:number;
    itemid: number;
    numberofitems: number;
    price: number
}