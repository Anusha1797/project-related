import { Component, OnInit } from '@angular/core';
import { Transactions } from '../Transactions';
import { SellerServiceService } from '../seller-service.service';


@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css']
})
export class CheckOutComponent implements OnInit {

  transactions: Transactions=new Transactions();

  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit(): void {
  }
  bid:String=localStorage.getItem("id");
  checkout() {
    console.log("checkout performed");
    this.sellerservice.checkout(this.transactions,this.bid).subscribe(message=>{alert('success');});
  }

}
