import { Component, OnInit } from '@angular/core';
import { Buyer } from '../Buyer';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-buyer-signup',
  templateUrl: './buyer-signup.component.html',
  styleUrls: ['./buyer-signup.component.css']
})
export class BuyerSignupComponent implements OnInit {

  buyer: Buyer=new Buyer();
  buyerdetails: any;

  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit(): void {
  }
  onSubmit() {
    console.log("Buyer Added");
    this.sellerservice.addBuyer(this.buyer).subscribe(buyerdetails=>this.buyer=buyerdetails);
  }

}
