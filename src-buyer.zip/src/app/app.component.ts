import { Component } from '@angular/core';
 import { SellerServiceService } from './seller-service.service';
import { Item } from './Item';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'ProjectApp';
  
  constructor(private sellerservice: SellerServiceService) {
    console.log("constructor invoked");
  }
  mgOnInit() {
  
  }
  
}
 
