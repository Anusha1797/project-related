export class Item {
    itemid: number;
    price: number;
    itemname: String;
    description: String;
    stocknumber: number;
    remarks: String
}