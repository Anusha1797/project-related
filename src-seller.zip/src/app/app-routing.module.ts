import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddSellerComponent } from './add-seller/add-seller.component';
import { AddItemComponent } from './add-item/add-item.component';
import { ProductsListComponent } from './products-list/products-list.component';
import { LoginComponent } from './login/login.component';



const routes: Routes = [
  {path:'login',component: LoginComponent},
  {path:'signup',component: AddSellerComponent},
  {path:'addproduct',component:  AddItemComponent},
  {path:'product',component:ProductsListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
